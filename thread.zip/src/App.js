import logo from './logo.svg';
import './App.css';
import { Comments } from './Components/Comments';

function App() {
  return (
    <div className="App">
      <Comments currentUserId="1"/>
    </div>
  );
}

export default App;
